import React from 'react'

const Employeedashboard = () => {
  return (
    <div>Employeedashboard</div>
  )
}

export default Employeedashboard